<?php defined('SYSPATH') OR die('No direct script access.');

interface HTTP_Request extends Kohana_HTTP_Request {}
