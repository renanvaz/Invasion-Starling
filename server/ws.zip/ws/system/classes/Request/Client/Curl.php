<?php defined('SYSPATH') OR die('No direct script access.');

class Request_Client_Curl extends Kohana_Request_Client_Curl {}
