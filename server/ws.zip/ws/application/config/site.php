<?php
return array(
    'title' 		=> 'Kohana PHP 3.3',
    'description'	=> '',
    'author' 		=> 'Renan Vaz',
    'GA'			=> 'UA-XXXXXX-X',
);