<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Default extends Controller {

	public function action_index(){
		$data = array(
			'status' => true,
			'data' => array(
				array(
					'client' 		=> 'Coca Cola',
					'clicktag' 		=> 'http://www.cocacola.com.br/',
					'description' 	=> 'Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.',
					'image'			=> URL::site(Img::get('coca.png', array('w' => 77, 'h' => 77))),
					'points'		=> 120,
				),
				array(
					'client' 		=> 'Facebook',
					'clicktag' 		=> 'http://www.facebook.com/',
					'description' 	=> 'Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.',
					'image'			=> URL::site(Img::get('facebook.png', array('w' => 77, 'h' => 77))),
					'points'		=> 80,
				),
				array(
					'client' 		=> 'Twitter',
					'clicktag' 		=> 'http://www.twitter.com/',
					'description' 	=> 'Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.',
					'image'			=> URL::site(Img::get('twitter.png', array('w' => 77, 'h' => 77))),
					'points'		=> 50,
				),
				array(
					'client' 		=> 'Apple',
					'clicktag' 		=> 'http://www.apple.com/',
					'description' 	=> 'Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.',
					'image'			=> URL::site(Img::get('apple.png', array('w' => 77, 'h' => 77))),
					'points'		=> 90,
				),
			),
		);

		$this->response->headers('Content-Type','application/json');
		$this->response->body(json_encode($data));

	}

}