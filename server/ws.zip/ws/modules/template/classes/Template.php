<?php defined('SYSPATH') or die('No direct script access.');

class Template extends Kohana_Template { }