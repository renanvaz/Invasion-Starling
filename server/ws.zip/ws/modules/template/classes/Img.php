<?php defined('SYSPATH') or die('No direct script access.');

class Img extends Kohana_Img { }