<?php
return array(
    'css_path'          => 'media/css/',
    'css_path_output'   => 'media/_css/',
    'js_path'           => 'media/js/',
    'js_path_output'    => 'media/_js/',
);