<?php

return array(
    'storage' => 'media/img/upload/',
    'output' => 'media/_img/'
);